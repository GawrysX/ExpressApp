import express from "express";
import mysql from "mysql";
import dotenv from "dotenv"; 

const app = express();
app.use(express.json());

dotenv.config();

const dbConfig = {
    host: process.env.DB_HOST,
    user: 'your_username', // Replace with your MySQL username
    database: 'movie_db',  // Specify the correct database name
};

const con = mysql.createConnection(dbConfig);

con.connect(async (err) => {
    if (err) throw err;
    console.log("Connected to the database");
});

app.post("/insert", async (req, res) => {
    console.log("Received an insert request:", req.body);
    const query = buildInsertQuery(req.body);

    try {
        await makeDatabaseQuery(query);
        res.json({ message: "Movie inserted successfully" });
    } catch (error) {
        console.error("Error in database query:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});

app.post("/search", async (req, res) => {
    console.log("Received a search request:", req.body);
    const query = buildSearchQuery(req.body);

    try {
        const results = await makeDatabaseQuery(query);
        res.json(results);
    } catch (error) {
        console.error("Error in database query:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});

app.delete("/delete/:movieTitle", async (req, res) => {
    const movieTitle = req.params.movieTitle;
    
    // Corrected SQL query with parameterized query to prevent SQL injection
    const sql = "DELETE FROM movies WHERE title = ?";

    con.query(sql, [movieTitle], (err, result) => {
        if (err) {
            console.error("Error in database query:", err);
            res.status(500).json({ error: "Internal server error" });
        } else {
            // Check the 'affectedRows' property in 'result' to determine if a row was deleted
            if (result.affectedRows > 0) {
                res.json({ message: "Movie deleted successfully" });
            } else {
                res.json({ message: "Movie not found or deleted" });
            }
        }
    });
});

function buildInsertQuery(movieData) {
    const { title, director, year } = movieData;
    return `INSERT INTO movies (title, director, year) VALUES ('${title}', '${director}', ${year})`;
}

function buildSearchQuery(params) {
    const { title, director, year } = params;
    const conditions = [];

    if (title) conditions.push(`title LIKE '%${title}%'`);
    if (director) conditions.push(`director LIKE '%${director}%'`);
    if (year) conditions.push(`year = ${year}`);

    let query = "SELECT * FROM movies";

    if (conditions.length > 0) {
        query += " WHERE " + conditions.join(" AND ");
    }

    return query;
}

function buildDeleteQuery(movieId) {
    return `DELETE FROM movies WHERE id = ${movieId}`;
}

function makeDatabaseQuery(sql) {
    return new Promise((resolve, reject) => {
        con.query(sql, (err, results) => {
            if (err) {
                reject(err);
            } else {
                resolve(results);
            }
        });
    });
}

app.listen(3000, () => {
    console.log("Server up and running on port 3000");
});
